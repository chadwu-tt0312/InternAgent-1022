python experiment.py \
  --data_root /datasets \
  --batch_size 32 \
  --lr 0.02 \
  --out_dir $1
